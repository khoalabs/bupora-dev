import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

db = SQLAlchemy()
migrate = Migrate()

def create_app():
  app = Flask(__name__, instance_relative_config=True)
  if os.getenv('FLASK_ENV', 'development') == 'production':
    app.config.from_object('app.config.ProductionConfig')
  else:
    app.config.from_object('app.config.DevelopmentConfig')
  try:
    os.makedirs(app.instance_path, exist_ok=True)
  except OSError:
    pass

  db.init_app(app)
  migrate.init_app(app, db)
  from app import routes
  routes.init_app(app)

  return app