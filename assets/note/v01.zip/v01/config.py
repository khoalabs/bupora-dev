r = r'''
export SECRET_KEY="very-long-random-string"
export API_KEY="your-api-key"
export FLASK_ENV=production
'''
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR.parent / 'instance'

class Config:
  # ===== Core =====
  SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-change-in-production')
  API_KEY = os.getenv('API_KEY')

  # ===== Database =====
  SQLALCHEMY_DATABASE_URI = os.getenv(
    'DATABASE_URL',
    f"sqlite:///{INSTANCE_DIR / 'site.db'}"
  )
  SQLALCHEMY_TRACK_MODIFICATIONS = False

  # SQLite performance tuning
  SQLALCHEMY_ENGINE_OPTIONS = {
    'connect_args': {'check_same_thread': False}
  }

  # ===== Caching (future-ready) =====
  SEND_FILE_MAX_AGE_DEFAULT = 60 * 60 * 24 * 30  # 30 days

  # ===== Security =====
  SESSION_COOKIE_HTTPONLY = True
  SESSION_COOKIE_SAMESITE = 'Lax'

  # ===== Content limits =====
  MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10MB upload limit


class DevelopmentConfig(Config):
  DEBUG = True

class ProductionConfig(Config):
  DEBUG = False
  SESSION_COOKIE_SECURE = True
  PREFERRED_URL_SCHEME = 'https'