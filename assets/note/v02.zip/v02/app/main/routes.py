from flask import render_template
from . import main_bp
from app.models import Post, Product

@main_bp.route("/")
def home():
  featured_posts = Post.query.filter_by(is_featured=True).limit(3).all()
  featured_products = Product.query.filter_by(is_featured=True).limit(3).all()

  return render_template(
    "pages/home.html",
    posts=featured_posts,
    products=featured_products
  )