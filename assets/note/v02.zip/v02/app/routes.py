from flask import request, render_template, current_app
from sqlalchemy import text
from app import db


def init_app(app):

  @app.route('/search')
  def search():
    query = request.args.get('q', '').strip()
    category = request.args.get('cat', '').strip()
    page = request.args.get('page', 1, type=int)

    if not query:
      return render_template(
        'search_results.html',
        posts=[],
        query=query,
        category=category,
        total=0,
        page=page
      )

    per_page = 20
    offset = (page - 1) * per_page

    sql = text("""
      SELECT post.id,
        post.title,
        post.slug,
        post.excerpt,
        post.category_slug,
        post.reading_time,
        post.created_at,
        bm25(post_fts) AS score
      FROM post
      JOIN post_fts ON post.id = post_fts.rowid
      WHERE post_fts MATCH :match_query
      AND post.is_published = 1
      AND (:category = '' OR post.category_slug = :category)
      ORDER BY score
      LIMIT :limit OFFSET :offset
    """)

    count_sql = text("""
      SELECT COUNT(*) as total
      FROM post
      JOIN post_fts ON post.id = post_fts.rowid
      WHERE post_fts MATCH :match_query
      AND post.is_published = 1
      AND (:category = '' OR post.category_slug = :category)
    """)

    params = {
      'match_query': query,
      'category': category,
      'limit': per_page,
      'offset': offset
    }

    results = db.session.execute(sql, params).fetchall()
    total = db.session.execute(count_sql, params).scalar()

    return render_template(
      'search_results.html',
      posts=results,
      query=query,
      category=category,
      total=total,
      page=page,
      per_page=per_page
    )