from flask import Flask
from .extensions import db, migrate

def create_app(config_class='config.Config'):
  app = Flask(__name__)
  app.config.from_object(config_class)

  db.init_app(app)
  migrate.init_app(app, db)

  # register blueprints
  from .main import main_bp
  from .blog import blog_bp
  from .shop import shop_bp
  from .topic import topic_bp

  app.register_blueprint(main_bp)
  app.register_blueprint(blog_bp, url_prefix='/blog')
  app.register_blueprint(shop_bp, url_prefix='/shop')
  app.register_blueprint(topic_bp, url_prefix='/topics')

  return app