import os

class Config:
  IS_PROD = os.environ.get('ENV', 'dev') == 'prod'
  if IS_PROD:
    SECRET_KEY = os.environ['SECRET_KEY']
    SQLALCHEMY_DATABASE_URI = os.environ['DATABASE_URL']
  else:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret')
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///dev.db')
  SQLALCHEMY_TRACK_MODIFICATIONS = False
  DEBUG = False if IS_PROD else True